/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo;

import com.example.demo.repo.CustomerRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author USER
 */
@Controller
@RequestMapping(path="/")
@Api("customer API Doc")
public class CustomerController {
    @Autowired
    private CustomerRepository customerRepository;
    
    @PostMapping(path="/customer") // Map ONLY POST Requests
    @ApiOperation("create")
    public @ResponseBody
    String addNewUser (@RequestParam String fname
    , @RequestParam String lname) {
    // @ResponseBody means the returned String is the response, not a view name
    // @RequestParam means it is a parameter from the GET or POST request
      Customer n = new Customer(fname, lname);
      customerRepository.save(n);
      return "Saved";
    }
    
    @GetMapping(path="/customer")
    @ApiOperation("get All")
    public @ResponseBody Iterable<Customer> getAllUsers() {
    // This returns a JSON or XML with the users
     return customerRepository.findAll();
    }
    
    @PostMapping(path="/customer/update/{id}") // Map ONLY POST Requests
    @ApiOperation("update")
    public @ResponseBody
    String UpdateUser (@PathVariable(name="id") int id,@RequestParam String fname
    , @RequestParam String lname) {
      Customer n =customerRepository.findById(id);
      n.setFirstname(fname);
      n.setLastname(lname);
      customerRepository.save(n);
      return "Saved";
    }
    
    @PostMapping(path="/customer/delete/{id}") // Map ONLY POST Requests
    @ApiOperation("delete")
    public @ResponseBody
    String DeleteUser (@PathVariable(name="id")int id) {
      Customer n =customerRepository.findById(id);
      customerRepository.delete(n);
      return "Deleted";
    }
    
    @GetMapping(path="/customer/{id}") // Map ONLY POST Requests
    @ApiOperation("getById")
    public @ResponseBody
    String FindUser (@PathVariable(name="id") int id) {
      Customer n =customerRepository.findById(id);
      String s = n.toString();
      return s;
    }
}
